import './App.css';
import ListTask from './components/ListTask';
import Addtask from './components/Addtask';
import { useState } from "react";
function App()
{
const[tasks,setTasks]=useState([]);
return (
<div>
<Addtask tasks={tasks} setTasks={setTasks}/>
<ListTask tasks={tasks} setTasks={setTasks}/>
</div>
);
}
export default App;